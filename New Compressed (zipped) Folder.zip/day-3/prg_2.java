//2.	Program to demonstrate logical operators.

public class prg_2 {
    public static void main(String[] args) {
        boolean x = true;
        boolean y = false;

        // Logical &
        System.out.println("x && y = " + (x && y)); 

        // Logical |
        System.out.println("x || y = " + (x || y));  

        // Logical NOT
        System.out.println("!x = " + (!x));
        System.out.println("!y = " + (!y));          
    }
}
